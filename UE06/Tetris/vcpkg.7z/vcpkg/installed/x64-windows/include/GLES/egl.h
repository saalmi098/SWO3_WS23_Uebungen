/*
** Copyright 2008-2020 The Khronos Group Inc.
** SPDX-License-Identifier: Apache-2.0
*/

/*
 * Skeleton egl.h to provide compatibility for early GLES 1.0
 * applications. Several early implementations included gl.h
 * in egl.h leading applications to include only egl.h
 */

#ifndef __legacy_egl_h_
#define __legacy_egl_h_

#include <EGL/egl.h>
#include <GLES/gl.h>

#endif /* __legacy_egl_h_ */
